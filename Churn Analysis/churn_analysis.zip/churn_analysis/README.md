# churn_analysis
Random project semester 5
